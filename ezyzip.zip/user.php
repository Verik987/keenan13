<?php 
	include "konek.php";

	$query = "SELECT * FROM member";
	$hasil = mysqli_query($connect,$query);

	echo "data user : <br>";
	foreach($hasil as $a) {
		echo $a['id_member']." ".$a['nm_member']." ".$a['telepon']."<br>";
	}
	?>