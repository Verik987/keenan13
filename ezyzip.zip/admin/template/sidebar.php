<!--sidebar start-->
<?php 
    $id = $_SESSION['admin']['id_member'];
    $hasil_profil = $lihat -> member_edit($id);
?>
<!-- Sidebar -->

   
    
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-dark topbar mb-4 static-top shadow">

            <!-- Sidebar Toggle (Topbar) -->
            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">

            <!-- Divider -->
    <hr class="sidebar-divider my-0">
    <hr class="sidebar-divider">
<li class="nav-item active">
    <a class="nav-link" href="user.php?page=pengaturan">
        <i class="fas fa-fw fa-cogs"></i>
        <span>|  USER</span></a>
</li>
<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="index.php">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>|   DASHBOARD</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">
<!-- Heading -->
<!-- <div class="sidebar-heading">
       Master
   </div> -->
<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item active">
    <a class="nav-link" href="index.php?page=barang">
        <i class="fas fa-shopping-basket"></i>
        <span>|   BARANG</span></a>
</li>
<li class="nav-item active">
    <a class="nav-link" href="index.php?page=kategori">
    <i class="fas fa-th-list"></i>
        <span>|   KATEGORI</span></a>
</li>
    <hr class="sidebar-divider">
<li class="nav-item active">
    <a class="nav-link" href="index.php?page=jual">
        <i class="fas fa-money-check-alt"></i>
        <span>|  TRANSAKSI JUAL</span></a>
</li>
<li class="nav-item active">
    <a class="nav-link" href="index.php?page=laporan">
    <i class="fas fa-pen"></i>
        <span>|  LAPORAN PENJUALAN</span></a>
</li>
<hr class="sidebar-divider">
<li class="nav-item active">
    <a class="nav-link" href="index.php?page=pengaturan">
        <i class="fas fa-fw fa-cogs"></i>
        <span>|  PENGATURAN TOKO</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>
                <!-- <div class="topbar-divider d-none d-sm-block"></div> -->
                <!-- Topbar Search -->
                <!-- Nav Item - User Information -->
                
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <img class="img-profile rounded-circle"
                            src="assets/img/user/<?php echo $hasil_profil['gambar'];?>">
                        <span
                          class="mr-2 d-none d-lg-inline text-light-600 small ml-2"><?php echo $hasil_profil['nm_member'];?></span>
                        <i class="fas fa-angle-down"></i>
                    </a>
                    
                    <!-- Dropdown - User Information -->
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                        aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="index.php?page=user">
                            <i class="fas fa-user fa-sm fa-fw mr-2 text-dark-400"></i>
                            PROFIL
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-dark-400"></i>
                            LOGOUT
                        </a>
                        
                    </div>
                </li>
            </ul>
        </nav>
        
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
        <div class="container-fluid">